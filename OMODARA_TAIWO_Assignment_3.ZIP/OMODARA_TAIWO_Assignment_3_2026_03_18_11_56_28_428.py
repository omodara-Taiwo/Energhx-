import streamlit as st
import numpy as np
import matplotlib.pyplot as plt
import plotly.graph_objects as go

# Page Configuration
st.set_page_config(page_title="Boiler & Rankine Optimizer", layout="wide")

## --- Logic Functions ---

def solve_2d_fvm_boiler(nx, ny, source_temp, fluid_temp):
    T = np.ones((nx, ny)) * 300
    for _ in range(500):
        T_old = T.copy()
        T[1:-1, 1:-1] = 0.25 * (T_old[2:, 1:-1] + T_old[:-2, 1:-1] + 
                                T_old[1:-1, 2:] + T_old[1:-1, :-2])
        T[:, -1] = source_temp  
        T[:, 0] = fluid_temp
    return T

## --- UI Layout ---

st.title("🔥 Reactor FVM & Rankine Cycle Optimizer")
st.markdown("Optimize heat flux via Finite Volume Method and visualize thermodynamic performance.")

# Sidebar for Hyperparameters
with st.sidebar:
    st.header("Simulation Parameters")
    source_t = st.slider("Source Temperature (K)", 700, 1900, 800)
    fluid_t = st.slider("Target Fluid Temp (K)", 300, 700, 300)
    
    st.divider()
    st.subheader("Grid Resolution (FVM)")
    nx = st.number_input("X-axis nodes", 10, 30, 20)
    ny = st.number_input("Y-axis nodes", 10, 60, 20)
    
    run_sim = st.button("Run Simulation", type="primary")

# Main Dashboard
col1, col2 = st.columns([1, 1])

if run_sim:
    # Run FVM
    temp_map = solve_2d_fvm_boiler(nx, ny, source_t, fluid_t)
    
    with col1:
        st.subheader("2D Boiler Heat Distribution")
        fig_fvm, ax_fvm = plt.subplots()
        im = ax_fvm.imshow(temp_map.T, origin='lower', cmap='hot', aspect='auto')
        plt.colorbar(im, label="Temp (K)")
        ax_fvm.set_xlabel("Length")
        ax_fvm.set_ylabel("Width")
        st.pyplot(fig_fvm)

    with col2:
        st.subheader("Thermodynamic Diagrams")
        # Cycle Data (Dynamic based on T-source)
        T_pts = [310, 312, source_t * 0.9, 450, 310] # Simplified coupling
        s_pts = [1.0, 1.05, 6.8, 7.2, 1.0]
        
        tab1, tab2 = st.tabs(["T-s Diagram", "P-v Diagram"])
        
        with tab1:
            fig_ts = go.Figure()
            fig_ts.add_trace(go.Scatter(x=s_pts, y=T_pts, mode='lines+markers', name='Rankine'))
            fig_ts.update_layout(xaxis_title="Entropy (s)", yaxis_title="Temp (T)", height=400)
            st.plotly_chart(fig_ts, use_container_width=True)
            
        with tab2:
            # Reusing your P-v logic
            v_pts = [0.001, 0.001, 0.1, 0.5, 0.001]
            P_pts = [10, 3000, 3000, 10, 10]
            fig_pv = go.Figure()
            fig_pv.add_trace(go.Scatter(x=v_pts, y=P_pts, mode='lines+markers', line=dict(color='orange')))
            fig_pv.update_layout(xaxis_title="Volume (v)", yaxis_title="Pressure (P)", yaxis_type="log", height=400)
            st.plotly_chart(fig_pv, use_container_width=True)

    # Efficiency Metric
    st.divider()
    efficiency = (1 - (310 / (source_t * 0.9))) * 100
    st.metric(label="Theoretical Rankine Efficiency", value=f"{efficiency:.2f}%", delta=f"{efficiency-40:.2f}% vs Baseline")
